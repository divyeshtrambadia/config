/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(function(){"use strict";var F={};F.numericFormatter=function(f){return sap.viz.api.env.Format.numericFormatter.apply(null,arguments);};return F;},true);
