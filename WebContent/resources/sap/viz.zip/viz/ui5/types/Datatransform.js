/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var D=B.extend("sap.viz.ui5.types.Datatransform",{metadata:{library:"sap.viz",aggregations:{autoBinning:{type:"sap.viz.ui5.types.Datatransform_autoBinning",multiple:false},dataSampling:{type:"sap.viz.ui5.types.Datatransform_dataSampling",multiple:false}}}});return D;});
