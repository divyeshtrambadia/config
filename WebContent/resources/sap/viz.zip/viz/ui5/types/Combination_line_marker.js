/*!
 * SAP UI development toolkit for HTML5 (SAPUI5)

(c) Copyright 2009-2016 SAP SE. All rights reserved
 */
sap.ui.define(['sap/viz/library','sap/viz/ui5/core/BaseStructuredType'],function(l,B){"use strict";var C=B.extend("sap.viz.ui5.types.Combination_line_marker",{metadata:{library:"sap.viz",properties:{visible:{type:"boolean",defaultValue:true},shape:{type:"string[]",defaultValue:['circle']},size:{type:"int",defaultValue:6},number:{type:"int",deprecated:true}}}});return C;});
